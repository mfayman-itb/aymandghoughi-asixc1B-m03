"""
Ayman Dghoughi
M03 UF1
14/09/2023
Exemple de de codi en Python
"""
# TODO Es pot fer servir per fer proves amb el GIT
print('Hello World!')